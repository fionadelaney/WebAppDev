<?php

$username = filter_input(INPUT_GET, 'username');
$password = filter_input(INPUT_GET, 'password');


if( 'bond' == $password )
{
    $message = 'password accepted';
}
else
{
    $message = 'error, invalid password';
}

//$message = "you entered '$username' and '$password'";

?>

<!DOCTYPE html>
<html><head><title>Authenticate Return</title></head>
<body>
<p>
    <?php echo $message; ?>

</p>
</body></html>