<?php

$username = filter_input(INPUT_GET, 'username');
$message = "Hello $username the number of GET data items = ";

$num_items = count($_GET);

$message .= $num_items;

$data_list = '';
foreach($_GET as $id => $value)
{
    //$data_list .= " $id = $value ";
    $data_list .= "_GET['$id'] = '$value'";
  //  $data_list .= '\n';
}


?>

<!DOCTYPE html>
<html><head><title>Authenticate Days</title></head>
<body>
<p>
    <?php print $message ;
    print $data_list ;?>

</p>
</body></html>