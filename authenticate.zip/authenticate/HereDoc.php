<!doctype html>
<html><head><title>row your boat</title>
<body>
<h3> Verse 1</h3>

	<?php 

	$verse = <<<_END
	<pre>
	Row Row Row your boat,
	Gently down the stream,
	Merrily Merrily Merrily Merrily,
	Life is but a dream.
	</pre>
_END;

	?>

<h3>Verse 2</h3>
<?php print $verse; ?>

<h3>Verse 3</h3>
<?php print $verse; ?>

</body>
</html>
