<?php
print "<!DOCTYPE html>";
print "<html>";
print "<head>";
print "<title>Hello HTML</title>";
print "</head>";
echo "<body>";
echo "<p>";
echo "Hello World";
echo "</p>";
echo "</body>";
echo "</html>";
?>