<?php $message = 'hello world';
?>

<!DOCTYPE html>
<html>
<head>
<title>Hello World</title>
</head>
<body>
<p>
    <?php
	echo $message;
	?>
</p>
</body>
</html>