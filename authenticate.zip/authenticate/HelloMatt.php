<?php
$firstName = 'Matt, ';
$message = "How are you? ";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hello Name</title>
</head>
<body>
<p>
    <?php
    echo '1st: Hello ';
    echo $firstName;
    echo $message;

    print "2nd: Hello $firstName how are you?";
    ?>
</p>
</body>
</html>